"""Shared CheapBuddy API helpers."""
