"""CheapBuddy ComfyUI node definitions."""
