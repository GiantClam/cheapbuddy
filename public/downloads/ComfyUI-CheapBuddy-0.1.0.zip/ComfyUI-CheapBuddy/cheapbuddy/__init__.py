"""Shared CheapBuddy API helpers."""
