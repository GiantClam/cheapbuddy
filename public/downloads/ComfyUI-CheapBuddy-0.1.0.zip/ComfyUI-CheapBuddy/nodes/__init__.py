"""CheapBuddy ComfyUI node definitions."""
